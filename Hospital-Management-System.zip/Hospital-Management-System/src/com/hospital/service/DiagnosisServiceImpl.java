package com.hospital.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.DiagnosisDao;
import com.hospital.exception.ApplicationException;
import com.hospital.model.DiagnosisPojo;

@Service("diagnosisService")
public class DiagnosisServiceImpl implements DiagnosisService {
	@Autowired
	DiagnosisDao diagnosisDao;

	@Override
	public ArrayList fetchValueDiagnosis() throws ApplicationException {
		ArrayList valueDetails = diagnosisDao.fetchValueDiagnosis();
		return valueDetails;
	}

	@Override
	public String registerDiagnosis(DiagnosisPojo diagnosisPojo) throws ApplicationException {
		String reportId = diagnosisDao.registerDiagnosis(diagnosisPojo);
		return reportId;
	}

	@Override
	public ArrayList fetchDiagnosisDetails() throws ApplicationException {
		ArrayList diagnosisDetails = diagnosisDao.fetchDiagnosisDetails();
		return diagnosisDetails;
	}

	@Override
	public void deleteDiagnosis(DiagnosisPojo diagnosisPojo) throws ApplicationException {
		diagnosisDao.deleteDiagnosis(diagnosisPojo);

	}

	@Override
	public void updateDiagnosis(DiagnosisPojo diagnosisPojo) throws ApplicationException {
		diagnosisDao.updateDiagnosis(diagnosisPojo);

	}

	@Override
	public DiagnosisPojo fetchDiagnosisUpdate(String reportId) throws ApplicationException {

		DiagnosisPojo diagnosisPojo = diagnosisDao.fetchDiagnosisUpdate(reportId);
		return diagnosisPojo;
	}

	@Override
	public ArrayList fetchDiagnosisDetailsPhysician(String physicianId) throws ApplicationException {

		ArrayList diagnosisPojo = diagnosisDao.fetchDiagnosisDetailsPhysician(physicianId);
		return diagnosisPojo;

	}

}
