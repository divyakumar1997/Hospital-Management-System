package com.hospital.service;

import java.util.ArrayList;

import com.hospital.exception.ApplicationException;

public interface PatientHistoryService {

	ArrayList fetchPatientHistory(String patientId) throws ApplicationException;

}
