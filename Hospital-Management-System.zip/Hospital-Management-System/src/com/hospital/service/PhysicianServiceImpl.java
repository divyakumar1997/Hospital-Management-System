package com.hospital.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.PhysicianDAO;
import com.hospital.exception.ApplicationException;

import com.hospital.model.PhysicianPojo;

@Service("physicianService")
public class PhysicianServiceImpl implements PhysicianService {

	@Autowired
	public PhysicianDAO physicianDAO;

	@Override
	public List fetchPhysician() throws ApplicationException {
		List list = physicianDAO.fetchPhysician();
		return list;
	}

	@Override
	public String addPhysician(PhysicianPojo physcianPojo) throws ApplicationException {
		String id = physicianDAO.addPhysician(physcianPojo);

		return id;
	}

	@Override
	public void updatePhysician(PhysicianPojo physcianPojo) throws ApplicationException {
		physicianDAO.updatePhysician(physcianPojo);
	}

	@Override
	public PhysicianPojo fetchPhysicianUpdate(String physicianId) throws ApplicationException {
		PhysicianPojo physicianPojo = physicianDAO.fetchPhysicianUpdate(physicianId);
		return physicianPojo;
	}

	@Override
	public List searchPhysician(String hospital, String speciality) throws ApplicationException {
		List list = physicianDAO.searchPhysician(hospital, speciality);
		return list;

	}

}
