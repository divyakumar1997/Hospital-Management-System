package com.hospital.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hospital.dao.PatientHistoryDao;
import com.hospital.exception.ApplicationException;

@Service("patientHistoryService")
public class PatientHistoryServiceImpl implements PatientHistoryService {
	@Autowired
	PatientHistoryDao patientHistoryDao;

	@Override
	public ArrayList fetchPatientHistory(String patientId) throws ApplicationException {

		ArrayList patientHistoryDetails = patientHistoryDao.fetchPatientHistory(patientId);
		return patientHistoryDetails;
	}

}
