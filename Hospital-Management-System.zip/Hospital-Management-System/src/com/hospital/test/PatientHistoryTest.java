package com.hospital.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.hospital.exception.ApplicationException;
import com.hospital.model.DiagnosisPojo;
import com.hospital.service.PatientHistoryService;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { TestBeanConfig.class })
public class PatientHistoryTest {
	@Autowired
	PatientHistoryService patientHistoryService;

	@Test
	public void testFetchPatientHistory() throws ApplicationException {
		ArrayList list1 = new ArrayList();
		ArrayList list2 = new ArrayList();
		DiagnosisPojo diagnosisPojo = new DiagnosisPojo("REP050", "PAT016", "PHY020", "06/09/2019", "06/10/2019", 150.0,
				"BloodPressure -90-140 mmHg", 0.7, "Thyroid -0.4-4 mlu/L", 120.0, "SugarLevel -<100 mg/dL", 0.0, " ",
				0.0, " ", 0.0, " ", "Take medicines", " ", "Fludrocortisone", "Not Required", "Metformin", " ", " ",
				" ");

		list1.add(diagnosisPojo);

		try {
			list2 = patientHistoryService.fetchPatientHistory("PAT016");
		} catch (AssertionError er) {
			assertEquals(list1, list2);
		}

	}

}
