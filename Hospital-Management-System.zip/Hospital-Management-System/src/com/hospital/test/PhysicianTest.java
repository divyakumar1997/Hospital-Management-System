package com.hospital.test;

import static org.junit.Assert.assertEquals;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;

import com.hospital.exception.ApplicationException;

import com.hospital.model.PhysicianPojo;
import com.hospital.service.PhysicianService;

@WebAppConfiguration
@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration(classes = { TestBeanConfig.class })
public class PhysicianTest {
	@Autowired
	PhysicianService physicianService;
	List list1 = new ArrayList();

	List list2 = new ArrayList();

	@Test
	public void fetchPhysician() throws ApplicationException {

		PhysicianPojo physicianPojo1 = new PhysicianPojo("PHY015", "Sam", "M", 35, "Male", "12-12-1984", 9876567891L,
				9876543213L, "sam@gmail.com", "1111", "M.G.R Street", "Villapuram", "Madurai", "TamilNadu", "625012",
				"M.B.B.S,M.D", "Ortho", "4.00 PM to 8.00 PM", "Meenakshi Hospital");
		PhysicianPojo physicianPojo2 = new PhysicianPojo("PHY016", "Janani", "H", 30, "Female", "23-12-1989",
				9876556788L, 0L, "janani@gmail.com", "11f", "Second Street", "Vadapalani", "Chennai", "TamilNadu",
				"689078", "dfg", "Neuro Surgeon", "4.00 PM to 8.00 PM", "Global Hospital");
		PhysicianPojo physicianPojo3 = new PhysicianPojo("PHY020", "Gayathri", "S", 40, "Female", "06/17/1979",
				98765434L, 78947545L, "gayathri@gmail.com", "111", "West Street", "Tambaram", "Chennai", "Tamilnadu",
				"632541", "M.B.B.S, M.D", "Ortho", "9.00 AM to 1.00 PM", "Gayathri Hospital");
		PhysicianPojo physicianPojo4 = new PhysicianPojo("PHY021", "Rahul", "K", 40, "Male", "06/25/1979", 9876897564L,
				0L, "rahul@gmail.com", "77", "Cauvery Street", "Main Road", "Chennai", "Tamil Nadu", "600098",
				"M.B.B.S", "ortho", "9.00 AM to 1.00 PM", "Meenakshi Hospital");
		PhysicianPojo physicianPojo5 = new PhysicianPojo("PHY022", "Divya", "K", 40, "Female", "06/12/1979",
				9823451678L, 0L, "divyak@gmail.com", "23", "Kamaraj Nagar", "Avadi", "Chennai", "Tamil Nadu", "600071",
				"M.B.B.S, M.D", "Pediatrician", "10.00 AM to 2.00 PM", "Meiot Hospital");
		PhysicianPojo physicianPojo6 = new PhysicianPojo("PHY023", "TestPhysician", "TestPhysician", 35, "Female",
				"06/19/1990", 1231231231L, 4564564564L, "tets@gmail.com", "Test", "TestAddress", "TestStreet",
				"Chennai", "Tamil Nadu", "123123", "MBBS", "Cardiologist", "5.00 PM to 9.00 PM", "Apollo Speciality");
		list1.add(physicianPojo1);
		list1.add(physicianPojo2);
		list1.add(physicianPojo3);
		list1.add(physicianPojo4);
		list1.add(physicianPojo5);
		list1.add(physicianPojo6);
		try {
			list2 = physicianService.fetchPhysician();
		} catch (AssertionError aex) {
			assertEquals(list1, list2);
		}

	}

	@Test
	public void fetchPhysicianUpdate() throws ApplicationException {
		PhysicianPojo physicianPojo2 = new PhysicianPojo();
		PhysicianPojo physicianPojo1 = new PhysicianPojo("PHY015", "Sam", "M", 35, "Male", "12-12-1984", 9876567891L,
				9876543213L, "sam@gmail.com", "1111", "M.G.R Street", "Villapuram", "Madurai", "TamilNadu", "625012",
				"M.B.B.S,M.D", "Ortho", "4.00 PM to 8.00 PM", "Meenakshi Hospital");
		try {
			physicianPojo2 = physicianService.fetchPhysicianUpdate("PHY015");
		} catch (AssertionError ae) {
			assertEquals(physicianPojo1, physicianPojo2);

		}

	}

	@Test
	public void searchPhysician() throws ApplicationException {
		PhysicianPojo physicianPojo2 = new PhysicianPojo("PHY016", "Janani", "H", 30, "Female", "23-12-1989",
				9876556788L, 0L, "janani@gmail.com", "11f", "Second Street", "Vadapalani", "Chennai", "TamilNadu",
				"689078", "dfg", "Neuro Surgeon", "4.00 PM to 8.00 PM", "Global Hospital");
		list1.add(physicianPojo2);
		try {
			list2 = physicianService.searchPhysician("Global Hospital", "Neuro Surgeon");
		} catch (AssertionError ae) {
			assertEquals(list1, list2);
		}
	}

}
