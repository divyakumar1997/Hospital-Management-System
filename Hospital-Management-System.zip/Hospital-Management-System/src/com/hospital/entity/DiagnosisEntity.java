package com.hospital.entity;

//import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "diagnosis")
public class DiagnosisEntity {

	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	@Column(name = "report_id")
	private String reportId;

	@ManyToOne
	@JoinColumn(name = "patient_id")
	private PatientEntity patientEntity;

	@ManyToOne
	@JoinColumn(name = "physician_id")
	private PhysicianEntity physicianEntity;

	@Column(name = "service_date")
	private String serviceDate;
	@Column(name = "test_result_date")
	private String testResultDate;
	@Column(name = "diag1_normal")
	private String normalValue1;
	@Column(name = "diag1_actual")
	private double actualValue1;
	@Column(name = "diag2_normal")
	private String normalValue2;
	@Column(name = "diag2_actual")
	private double actualValue2;
	@Column(name = "diag3_normal")
	private String normalValue3;
	@Column(name = "diag3_actual")
	private double actualValue3;
	@Column(name = "diag4_normal")
	private String normalValue4;
	@Column(name = "diag4_actual")
	private double actualValue4;
	@Column(name = "diag5_normal")
	private String normalValue5;
	@Column(name = "diag5_actual")
	private double actualValue5;
	@Column(name = "diag6_normal")
	private String normalValue6;
	@Column(name = "diag6_actual")
	private double actualValue6;

	@Column(name = "physician_comments")
	private String physicianComments;
	@Column(name = "other_info")
	private String otherInfo;
	@Column(name = "medicine_1")
	private String medicine1;
	@Column(name = "medicine_2")
	private String medicine2;
	@Column(name = "medicine_3")
	private String medicine3;
	@Column(name = "medicine_4")
	private String medicine4;
	@Column(name = "medicine_5")
	private String medicine5;
	@Column(name = "medicine_6")
	private String medicine6;

	public String getReportId() {
		return reportId;
	}

	public PatientEntity getPatientEntity() {
		return patientEntity;
	}

	public PhysicianEntity getPhysicianEntity() {
		return physicianEntity;
	}

	public String getServiceDate() {
		return serviceDate;
	}

	public String getNormalValue1() {
		return normalValue1;
	}

	public double getActualValue1() {
		return actualValue1;
	}

	public String getTestResultDate() {
		return testResultDate;
	}

	public String getNormalValue2() {
		return normalValue2;
	}

	public String getNormalValue3() {
		return normalValue3;
	}

	public double getActualValue3() {
		return actualValue3;
	}

	public double getActualValue2() {
		return actualValue2;
	}

	public double getActualValue4() {
		return actualValue4;
	}

	public String getNormalValue5() {
		return normalValue5;
	}

	public String getNormalValue4() {
		return normalValue4;
	}

	public double getActualValue5() {
		return actualValue5;
	}

	public double getActualValue6() {
		return actualValue6;
	}

	public String getPhysicianComments() {
		return physicianComments;
	}

	public String getOtherInfo() {
		return otherInfo;
	}

	public String getMedicine1() {
		return medicine1;
	}

	public String getMedicine2() {
		return medicine2;
	}

	public String getMedicine5() {
		return medicine5;
	}

	public String getNormalValue6() {
		return normalValue6;
	}

	public String getMedicine3() {
		return medicine3;
	}

	public String getMedicine4() {
		return medicine4;
	}

	public String getMedicine6() {
		return medicine6;
	}

	public void setPatientEntity(PatientEntity patientEntity) {
		this.patientEntity = patientEntity;
	}

	public void setPhysicianEntity(PhysicianEntity physicianEntity) {
		this.physicianEntity = physicianEntity;
	}

	public void setTestResultDate(String testResultDate) {
		this.testResultDate = testResultDate;
	}

	public void setServiceDate(String serviceDate) {
		this.serviceDate = serviceDate;
	}

	public void setReportId(String reportId) {
		this.reportId = reportId;
	}

	public void setNormalValue2(String normalValue2) {
		this.normalValue2 = normalValue2;
	}

	public void setNormalValue1(String normalValue1) {
		this.normalValue1 = normalValue1;
	}

	public void setActualValue1(double actualValue1) {
		this.actualValue1 = actualValue1;
	}

	public void setActualValue2(double actualValue2) {
		this.actualValue2 = actualValue2;
	}

	public void setNormalValue4(String normalValue4) {
		this.normalValue4 = normalValue4;
	}

	public void setActualValue4(double actualValue4) {
		this.actualValue4 = actualValue4;
	}

	public void setActualValue3(double actualValue3) {
		this.actualValue3 = actualValue3;
	}

	public void setNormalValue5(String normalValue5) {
		this.normalValue5 = normalValue5;
	}

	public void setActualValue5(double actualValue5) {
		this.actualValue5 = actualValue5;
	}

	public void setPhysicianComments(String physicianComments) {
		this.physicianComments = physicianComments;
	}

	public void setNormalValue6(String normalValue6) {
		this.normalValue6 = normalValue6;
	}

	public void setActualValue6(double actualValue6) {
		this.actualValue6 = actualValue6;
	}

	public void setOtherInfo(String otherInfo) {
		this.otherInfo = otherInfo;
	}

	public void setMedicine1(String medicine1) {
		this.medicine1 = medicine1;
	}

	public void setMedicine6(String medicine6) {
		this.medicine6 = medicine6;
	}

	public void setMedicine3(String medicine3) {
		this.medicine3 = medicine3;
	}

	public void setMedicine4(String medicine4) {
		this.medicine4 = medicine4;
	}

	public void setMedicine5(String medicine5) {
		this.medicine5 = medicine5;
	}

	public void setMedicine2(String medicine2) {
		this.medicine2 = medicine2;
	}

	public void setNormalValue3(String normalValue3) {
		this.normalValue3 = normalValue3;
	}

}
