package com.hospital.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity

@Table(name = "admin")
public class AdminEntity {
	@Id
	@GeneratedValue(generator = "system-uuid")
	@GenericGenerator(name = "system-uuid", strategy = "uuid")
	@Column(name = "adm_id")
	private String adminId;

	@Column(name = "first_name")
	private String firstName;

	@Column(name = "last_name")
	private String lastName;

	@Column(name = "age")
	private int age;
	@Column(name = "gender")
	private String gender;

	@Column(name = "dob")
	private String dateOfBirth;

	@Column(name = "contact_number")
	private long contactNumber;

	@Column(name = "alt_contact")
	private long alternateContactNumber;

	@Column(name = "email_id")
	private String emailId;

	@Column(name = "password")
	private String password;

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setAlternateContactNumber(long alternateContactNumber) {
		this.alternateContactNumber = alternateContactNumber;
	}

	public String getLastName() {
		return lastName;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAdminId() {
		return adminId;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public int getAge() {
		return age;
	}

	public String getGender() {
		return gender;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public long getAlternateContactNumber() {
		return alternateContactNumber;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getEmailId() {
		return emailId;
	}

	public String getPassword() {
		return password;
	}

}
