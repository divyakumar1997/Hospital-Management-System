package com.hospital.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "diagnosis_value")
public class DiagnosisValueEntity {
	@Id
	@Column(name = "diagnosis")
	private String diagnosis;
	@Column(name = "value")
	private String value;

	public DiagnosisValueEntity() {
		super();
	}

	public DiagnosisValueEntity(String diagnosis, String value) {
		super();
		this.diagnosis = diagnosis;
		this.value = value;
	}

	public String getDiagnosis() {
		return diagnosis;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
