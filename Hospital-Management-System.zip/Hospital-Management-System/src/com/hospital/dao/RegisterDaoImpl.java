package com.hospital.dao;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;

import com.hospital.entity.AdminEntity;
import com.hospital.entity.PhysicianEntity;
import com.hospital.exception.ApplicationException;
import com.hospital.model.AdminPojo;
import com.hospital.model.PhysicianPojo;

@Repository("registerDAO")
public class RegisterDaoImpl implements RegisterDao {

	// Admin Registration
	@Override
	public String registerAdmin(AdminPojo adminPojo) throws ApplicationException {

		SessionFactory sessionfactory18 = null;
		Session session18 = null;
		String adminId = null;
		String name = null;
		try {
			sessionfactory18 = HibernateUtil.getSessionFactory();
			session18 = sessionfactory18.openSession();
			Transaction transaction18 = session18.beginTransaction();

			AdminEntity adminEntity = new AdminEntity();

			adminEntity.setFirstName(adminPojo.getFirstName());
			adminEntity.setLastName(adminPojo.getLastName());
			adminEntity.setAge(adminPojo.getAge());
			adminEntity.setGender(adminPojo.getGender());
			adminEntity.setDateOfBirth(adminPojo.getDateOfBirth());

			if (Long.toString(adminPojo.getAlternateContactNumber()) != null) {
				adminEntity.setAlternateContactNumber(adminPojo.getAlternateContactNumber());
			}

			adminEntity.setEmailId(adminPojo.getEmailId());
			adminEntity.setPassword(adminPojo.getPassword());
			name = adminEntity.getFirstName();

			session18.save(adminEntity);
			session18.flush();

			transaction18.commit();

			Query query = session18.createQuery("from AdminEntity where first_name='" + name + "'");
			List<AdminEntity> list = query.list();
			for (AdminEntity entity : list) {
				adminId = entity.getAdminId();
			}

		} catch (HibernateException he18) {
			ApplicationException ae18 = new ApplicationException(he18.getMessage());
			throw ae18;

		}

		finally {
			session18.close();
		}

		return adminId;
	}

	// Login Validation
	@Override
	public int adminLogin(AdminPojo adminPojo) throws ApplicationException {
		int result = 0;
		SessionFactory sessionfactory19 = null;
		Session session19 = null;
		try {
			sessionfactory19 = HibernateUtil.getSessionFactory();
			session19 = sessionfactory19.openSession();

			List l1 = (List) session19.createQuery("from AdminEntity where adm_id='" + adminPojo.getAdminId() + "'")
					.list();
			List l2 = (List) session19.createQuery("from AdminEntity where password='" + adminPojo.getPassword() + "'")
					.list();
			result = RegisterDaoImpl.check(l1, l2);

		} catch (HibernateException he19) {
			ApplicationException ae19 = new ApplicationException(he19.getMessage());
			throw ae19;

		}

		finally {
			session19.close();
		}
		return result;
	}

	// Get Admin Name to validate the session is valid or not
	@Override
	public String getAdminName(String adminId) throws ApplicationException {
		String adminName = null;
		SessionFactory sessionfactory20 = null;
		Session session20 = null;
		try {
			sessionfactory20 = HibernateUtil.getSessionFactory();
			session20 = sessionfactory20.openSession();
			AdminEntity adminEntity = new AdminEntity();
			adminEntity.setAdminId(adminId);
			List l3 = (List) session20.createQuery("from AdminEntity where adm_id='" + adminEntity.getAdminId() + "'")
					.list();
			Iterator iterator = l3.iterator();
			if (iterator.hasNext()) {
				AdminEntity adminEntityName = (AdminEntity) l3.get(0);
				adminName = adminEntityName.getFirstName();
			}
		} catch (HibernateException he20) {
			ApplicationException ae20 = new ApplicationException(he20.getMessage());
			throw ae20;

		}

		finally {
			session20.close();
		}

		return adminName;
	}

	@Override
	public int physicianLogin(PhysicianPojo physicianPojo) throws ApplicationException {
		int result = 0;
		SessionFactory sessionfactory21 = null;
		Session session21 = null;
		try {
			sessionfactory21 = HibernateUtil.getSessionFactory();
			session21 = sessionfactory21.openSession();

			List l4 = (List) session21
					.createQuery("from PhysicianEntity where physician_id='" + physicianPojo.getPhysicianId() + "'")
					.list();
			List l5 = (List) session21
					.createQuery("from PhysicianEntity where password='" + physicianPojo.getPassword() + "'").list();
			result = RegisterDaoImpl.check(l4, l5);

		} catch (HibernateException he21) {
			ApplicationException ae21 = new ApplicationException(he21.getMessage());
			throw ae21;

		}

		finally {
			session21.close();
		}
		return result;
	}

	@Override
	public String getPhysicianName(String physicianId) throws ApplicationException {
		String physicianName = null;
		SessionFactory sessionfactory22 = null;
		Session session22 = null;
		try {
			sessionfactory22 = HibernateUtil.getSessionFactory();
			session22 = sessionfactory22.openSession();
			PhysicianEntity physicianEntity = new PhysicianEntity();
			physicianEntity.setPhysicianId(physicianId);
			List l6 = (List) session22
					.createQuery("from PhysicianEntity where physician_id='" + physicianEntity.getPhysicianId() + "'")
					.list();
			Iterator iterator = l6.iterator();
			if (iterator.hasNext()) {
				PhysicianEntity physicianEntityName = (PhysicianEntity) l6.get(0);
				physicianName = physicianEntityName.getFirstName();
			}
		} catch (HibernateException he22) {
			ApplicationException ae22 = new ApplicationException(he22.getMessage());
			throw ae22;

		}

		finally {
			session22.close();
		}

		return physicianName;
	}

	static int check(List l1, List l2) {
		int result = 0;
		Iterator iterator = l1.iterator();
		Iterator iterator1 = l2.iterator();

		if (iterator.hasNext() && iterator1.hasNext()) {

			result = 1;
		}

		else if (iterator.hasNext() && l2.size() == 0) {
			result = 0;
		} else if (l1.size() == 0 && l2.size() == 0) {
			result = -1;
		}
		return result;
	}
}
