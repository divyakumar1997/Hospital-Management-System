package com.hospital.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.hospital.entity.PhysicianEntity;
import com.hospital.exception.ApplicationException;

import com.hospital.model.PhysicianPojo;

@Repository("physicianDAO")

public class PhysicianDAOImpl implements PhysicianDAO {

	// fetchPhysician method will fetch all the physician details
	@Override
	public List fetchPhysician() throws ApplicationException {
		SessionFactory sessionFactory13 = null;
		Session session13 = null;
		sessionFactory13 = HibernateUtil.getSessionFactory();
		session13 = sessionFactory13.openSession();
		List list1 = null;
		try {
			List list = session13.createQuery("from PhysicianEntity").list();

			list1 = new ArrayList();
			for (int i = 0; i < list.size(); i++) {
				PhysicianEntity physicianEntity = (PhysicianEntity) list.get(i);
				PhysicianPojo physicianPojo = new PhysicianPojo();
				physicianPojo.setPhysicianId(physicianEntity.getPhysicianId());
				physicianPojo = PhysicianDAOImpl.physicianPojoMethod(physicianPojo, physicianEntity);

				list1.add(physicianPojo);
			}
		} catch (HibernateException he13) {
			ApplicationException ae13 = new ApplicationException(he13.getMessage());
			throw ae13;
		} finally {
			session13.close();
		}

		return list1;
	}

	// addPhysician method is used to insert physician insert into database
	@Override
	public String addPhysician(PhysicianPojo physicianPojo) throws ApplicationException {
		SessionFactory sessionFactory14 = null;
		Session session14 = null;
		Transaction transaction14 = null;
		sessionFactory14 = HibernateUtil.getSessionFactory();
		session14 = sessionFactory14.openSession();
		transaction14 = session14.beginTransaction();

		String physicianId = null;
		try {
			PhysicianEntity physicianEntity = new PhysicianEntity();
			physicianEntity = PhysicianDAOImpl.physicianEntityMethod(physicianPojo, physicianEntity);

			session14.save(physicianEntity);

			transaction14.commit();
			physicianEntity = session14.get(PhysicianEntity.class, physicianEntity.getPhysicianId());

			String name = physicianEntity.getFirstName();

			Query query = session14.createQuery("from PhysicianEntity where first_name= '" + name + "'");
			List<PhysicianEntity> list = query.list();

			for (PhysicianEntity physicianEntity1 : list) {
				physicianId = physicianEntity1.getPhysicianId();
			}

		} catch (HibernateException he14) {
			ApplicationException ae14 = new ApplicationException(he14.getMessage());
			throw ae14;
		}

		finally {
			session14.close();
		}

		return physicianId;
	}

	// By calling updatePhysician method admin can able to update the details of
	// existing physician
	@Override
	public void updatePhysician(PhysicianPojo physicianPojo) throws ApplicationException {
		SessionFactory sessionFactory15 = null;
		Session session15 = null;
		Transaction transaction15 = null;
		try {
			sessionFactory15 = HibernateUtil.getSessionFactory();
			session15 = sessionFactory15.openSession();
			transaction15 = session15.beginTransaction();
			PhysicianEntity physicianEntity = session15.get(PhysicianEntity.class, physicianPojo.getPhysicianId());
			physicianEntity = PhysicianDAOImpl.physicianEntityMethod(physicianPojo, physicianEntity);

			transaction15.commit();

		} catch (HibernateException he15) {
			ApplicationException ae15 = new ApplicationException(he15.getMessage());
			throw ae15;

		} finally {
			session15.close();
		}

	}

	// fetchPhysicianUpdate Method is used to pass the value to updation form
	@Override
	public PhysicianPojo fetchPhysicianUpdate(String physicianId) throws ApplicationException {
		SessionFactory sessionFactory16 = null;
		Session session16 = null;

		PhysicianPojo physicianPojo = new PhysicianPojo();
		try {
			sessionFactory16 = HibernateUtil.getSessionFactory();
			session16 = sessionFactory16.openSession();
			PhysicianEntity physicianEntity = new PhysicianEntity();
			physicianEntity = session16.get(PhysicianEntity.class, physicianId);
			physicianPojo.setPhysicianId(physicianId);
			physicianPojo = PhysicianDAOImpl.physicianPojoMethod(physicianPojo, physicianEntity);

		} catch (HibernateException he16) {
			ApplicationException ae16 = new ApplicationException(he16.getMessage());
			throw ae16;
		} finally {
			session16.close();
		}
		return physicianPojo;
	}

	// searchPhysician method is used to search the physician based on their
	// speciality ad hospital
	@Override
	public List searchPhysician(String hospital, String speciality) throws ApplicationException {
		SessionFactory sessionFactory17 = null;
		Session session17 = null;

		sessionFactory17 = HibernateUtil.getSessionFactory();
		session17 = sessionFactory17.openSession();

		List physicianList = null;
		try {

			Query query = session17.createQuery(
					"from PhysicianEntity where hospital= '" + hospital + "' and speciality='" + speciality + "'");
			physicianList = query.list();

		}

		catch (HibernateException e17) {
			ApplicationException ae17 = new ApplicationException(e17.getMessage());
			throw ae17;
		} finally {
			session17.close();
		}
		return physicianList;

	}

	static PhysicianPojo physicianPojoMethod(PhysicianPojo physicianPojo, PhysicianEntity physicianEntity) {
		physicianPojo.setAddressLine1(physicianEntity.getAddressLine1());
		physicianPojo.setAddressLine2(physicianEntity.getAddressLine2());
		physicianPojo.setAge(physicianEntity.getAge());
		physicianPojo.setAlternateContactNumber(physicianEntity.getAlternateContact());
		physicianPojo.setCity(physicianEntity.getCity());

		physicianPojo.setContactNumber(physicianEntity.getContactNumber());
		physicianPojo.setDateOfBirth(physicianEntity.getDob());
		physicianPojo.setEmailId(physicianEntity.getEmail());
		physicianPojo.setFirstName(physicianEntity.getFirstName());
		physicianPojo.setGender(physicianEntity.getGender());
		physicianPojo.setLastName(physicianEntity.getLastName());
		physicianPojo.setState(physicianEntity.getState());
		physicianPojo.setZipCode(physicianEntity.getZipCode());
		physicianPojo.setDegree(physicianEntity.getDegree());
		physicianPojo.setSpeciality(physicianEntity.getSpeciality());
		physicianPojo.setWorkHours(physicianEntity.getWorkHours());
		physicianPojo.setHospital(physicianEntity.getHospital());
		return physicianPojo;
	}

	static PhysicianEntity physicianEntityMethod(PhysicianPojo physicianPojo, PhysicianEntity physicianEntity) {
		physicianEntity.setFirstName(physicianPojo.getFirstName());
		physicianEntity.setLastName(physicianPojo.getLastName());
		physicianEntity.setAge(physicianPojo.getAge());
		physicianEntity.setAddressLine1(physicianPojo.getAddressLine1());

		physicianEntity.setDob(physicianPojo.getDateOfBirth());
		physicianEntity.setGender(physicianPojo.getGender());
		physicianEntity.setContactNumber(physicianPojo.getContactNumber());
		if (physicianPojo.getAlternateContactNumber() != 0) {
			physicianEntity.setAlternateContact(physicianPojo.getAlternateContactNumber());
		}
		physicianEntity.setEmail(physicianPojo.getEmailId());
		physicianEntity.setPassword(physicianPojo.getPassword());
		physicianEntity.setZipCode(physicianPojo.getZipCode());
		physicianEntity.setDegree(physicianPojo.getDegree());
		physicianEntity.setSpeciality(physicianPojo.getSpeciality());
		physicianEntity.setWorkHours(physicianPojo.getWorkHours());
		physicianEntity.setHospital(physicianPojo.getHospital());
		if (physicianPojo.getAddressLine2() != null) {
			physicianEntity.setAddressLine2(physicianPojo.getAddressLine2());
		}
		physicianEntity.setCity(physicianPojo.getCity());
		physicianEntity.setState(physicianPojo.getState());
		return physicianEntity;
	}
}
