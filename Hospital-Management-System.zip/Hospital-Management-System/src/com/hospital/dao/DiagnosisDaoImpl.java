package com.hospital.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.stereotype.Repository;

import com.hospital.entity.DiagnosisEntity;
import com.hospital.entity.DiagnosisValueEntity;
import com.hospital.entity.PatientEntity;
import com.hospital.entity.PhysicianEntity;
import com.hospital.exception.ApplicationException;
import com.hospital.model.DiagnosisPojo;
import com.hospital.model.DiagnosisValuePojo;

@Repository("diagnosisDao")
public class DiagnosisDaoImpl implements DiagnosisDao {

	// This method will fetch the normal values
	@Override

	public ArrayList fetchValueDiagnosis() throws ApplicationException {
		SessionFactory sessionFactory1 = null;
		Session session1 = null;
		ArrayList valueDetails = new ArrayList();
		try {
			sessionFactory1 = HibernateUtil.getSessionFactory();
			session1 = sessionFactory1.openSession();
			List list = session1.createQuery("from DiagnosisValueEntity").list();
			for (int i = 0; i < list.size(); i++) {
				DiagnosisValueEntity valueEntity = (DiagnosisValueEntity) list.get(i);
				DiagnosisValuePojo valuePojo = new DiagnosisValuePojo();
				valuePojo.setDiagnosis(valueEntity.getDiagnosis());
				valuePojo.setValue(valueEntity.getValue());
				valueDetails.add(valuePojo);
			}

		} catch (HibernateException he1) {
			ApplicationException ae1 = new ApplicationException(he1.getMessage());
			throw ae1;

		} finally {
			session1.close();
		}
		return valueDetails;

	}

	// registerDiagnosis method is used to add the diagnosis report details of the
	// patient.
	@Override
	public String registerDiagnosis(DiagnosisPojo pojo) throws ApplicationException {
		String reportId = " ";
		SessionFactory sessionFactory2 = null;
		Session session2 = null;
		Transaction transaction2 = null;
		DiagnosisEntity diagnosisEntity = new DiagnosisEntity();
		PatientEntity patientEntity = new PatientEntity();
		PhysicianEntity physicianEntity = new PhysicianEntity();

		try {
			sessionFactory2 = HibernateUtil.getSessionFactory();
			session2 = sessionFactory2.openSession();
			transaction2 = session2.beginTransaction();

		
			patientEntity = session2.get(PatientEntity.class, pojo.getPatientId());
			diagnosisEntity.setPatientEntity(patientEntity);

			physicianEntity = session2.get(PhysicianEntity.class, pojo.getPhysicianId());
			diagnosisEntity.setPhysicianEntity(physicianEntity);
			diagnosisEntity.setServiceDate(pojo.getServiceDate());

			String physicianId = pojo.getPhysicianId();
			session2.save(diagnosisEntity);
			transaction2.commit();
			Query query = session2.createQuery("from DiagnosisEntity where physician_id='" + physicianId + "'");
			List<DiagnosisEntity> list = query.list();
			for (DiagnosisEntity entity : list) {
				reportId = entity.getReportId();
			}

		} catch (HibernateException he2) {
			ApplicationException ae2 = new ApplicationException(he2.getMessage());
			throw ae2;
		} finally {
			session2.close();
		}

		return reportId;
	}

	// fetchDiagnosisDetails method is used to fetch all records in diagnosis table.
	@Override
	public ArrayList fetchDiagnosisDetails() throws ApplicationException {
		ArrayList diagnosisDetails = new ArrayList();
		SessionFactory sessionFactory3 = null;
		Session session3 = null;

		try {
			sessionFactory3 = HibernateUtil.getSessionFactory();
			session3 = sessionFactory3.openSession();
			List list = session3.createQuery("from DiagnosisEntity").list();

			for (int i = 0; i < list.size(); i++) {
				DiagnosisEntity diagnosisEntity = (DiagnosisEntity) list.get(i);
				DiagnosisPojo diagnosisPojo = new DiagnosisPojo();

				diagnosisPojo.setReportId(diagnosisEntity.getReportId());

				diagnosisPojo = DiagnosisDaoImpl.diagnosisPojoMethod(diagnosisEntity, diagnosisPojo);
				diagnosisPojo.setPhysicianId(diagnosisEntity.getPhysicianEntity().getPhysicianId());

				diagnosisDetails.add(diagnosisPojo);
			}

		} catch (HibernateException he3) {
			ApplicationException ae3 = new ApplicationException(he3.getMessage());
			throw ae3;

		} finally {
			session3.close();
		}
		return diagnosisDetails;
	}

	@Override
	public ArrayList fetchDiagnosisDetailsPhysician(String physicianId) throws ApplicationException {
		ArrayList diagnosisDetails = new ArrayList();
		SessionFactory sessionFactory4 = null;
		Session session4 = null;

		try {
			sessionFactory4 = HibernateUtil.getSessionFactory();
			session4 = sessionFactory4.openSession();
			List list = session4.createQuery("from DiagnosisEntity where physician_id='" + physicianId + "'").list();

			for (int j = 0; j < list.size(); j++) {
				DiagnosisPojo diagnosisPojo = new DiagnosisPojo();
				DiagnosisEntity diagnosisEntity = (DiagnosisEntity) list.get(j);

				diagnosisPojo.setReportId(diagnosisEntity.getReportId());
				diagnosisPojo = DiagnosisDaoImpl.diagnosisPojoMethod(diagnosisEntity, diagnosisPojo);

				diagnosisDetails.add(diagnosisPojo);
			}

		} catch (HibernateException he4) {
			ApplicationException ae4 = new ApplicationException(he4.getMessage());
			throw ae4;

		} finally {
			session4.close();
		}
		return diagnosisDetails;
	}

	// deleteDiagnosis method is used to delete the particular patient diagnosis
	// details from database.
	@Override
	public void deleteDiagnosis(DiagnosisPojo diagnosisPojo) throws ApplicationException {
		SessionFactory sessionFactory5 = null;
		Session session5 = null;

		sessionFactory5 = HibernateUtil.getSessionFactory();
		session5 = sessionFactory5.openSession();

		try {
			DiagnosisEntity diagnosisEntity = (DiagnosisEntity) session5.load(DiagnosisEntity.class,
					diagnosisPojo.getReportId());
			session5.delete(diagnosisEntity);
			session5.getTransaction().commit();
		}

		catch (HibernateException e5) {
			ApplicationException ae5 = new ApplicationException(e5.getMessage());
			throw ae5;
		} finally {
			session5.close();
		}

	}

	// By calling updateDiagnosis method ,admin can able to update the details of
	// existing patient diagnosis report
	@Override
	public void updateDiagnosis(DiagnosisPojo diagnosisPojo) throws ApplicationException {
		SessionFactory sessionFactory6 = null;
		Session session6 = null;
		Transaction transaction6 = null;
		PatientEntity patientEntity = new PatientEntity();
		PhysicianEntity physicianEntity = new PhysicianEntity();

		try {
			sessionFactory6 = HibernateUtil.getSessionFactory();
			session6 = sessionFactory6.openSession();
			transaction6 = session6.beginTransaction();
			DiagnosisEntity diagnosisEntity = session6.get(DiagnosisEntity.class, diagnosisPojo.getReportId());
			diagnosisEntity.setReportId(diagnosisPojo.getReportId());
			
			patientEntity = session6.get(PatientEntity.class, diagnosisPojo.getPatientId());
			diagnosisEntity.setPatientEntity(patientEntity);

			physicianEntity = session6.get(PhysicianEntity.class, diagnosisPojo.getPhysicianId());
			diagnosisEntity.setPhysicianEntity(physicianEntity);
			diagnosisEntity.setServiceDate(diagnosisPojo.getServiceDate());
			diagnosisEntity.setTestResultDate(diagnosisPojo.getTestResultDate());
			diagnosisEntity.setActualValue1(diagnosisPojo.getActualValue1());
			diagnosisEntity.setActualValue2(diagnosisPojo.getActualValue2());
			diagnosisEntity.setActualValue3(diagnosisPojo.getActualValue3());
			diagnosisEntity.setActualValue4(diagnosisPojo.getActualValue4());
			diagnosisEntity.setActualValue5(diagnosisPojo.getActualValue5());
			diagnosisEntity.setActualValue6(diagnosisPojo.getActualValue6());
			diagnosisEntity.setNormalValue1(diagnosisPojo.getNormalValue1());
			diagnosisEntity.setNormalValue2(diagnosisPojo.getNormalValue2());
			diagnosisEntity.setNormalValue3(diagnosisPojo.getNormalValue3());
			diagnosisEntity.setNormalValue4(diagnosisPojo.getNormalValue4());
			diagnosisEntity.setNormalValue5(diagnosisPojo.getNormalValue5());
			diagnosisEntity.setNormalValue6(diagnosisPojo.getNormalValue6());
			diagnosisEntity.setMedicine1(diagnosisPojo.getMedicine1());
			diagnosisEntity.setMedicine2(diagnosisPojo.getMedicine2());
			diagnosisEntity.setMedicine3(diagnosisPojo.getMedicine3());
			diagnosisEntity.setMedicine4(diagnosisPojo.getMedicine4());
			diagnosisEntity.setMedicine5(diagnosisPojo.getMedicine5());
			diagnosisEntity.setMedicine6(diagnosisPojo.getMedicine6());
			diagnosisEntity.setPhysicianComments(diagnosisPojo.getPhysicianComment());
			diagnosisEntity.setOtherInfo(diagnosisPojo.getOtherInfo());

			session6.save(diagnosisEntity);
			transaction6.commit();

		} catch (HibernateException he6) {
			ApplicationException ae6 = new ApplicationException(he6.getMessage());
			throw ae6;

		} finally {
			session6.close();
		}

	}

	// fetchDiagnosisUpdate Method is used to pass the value to updation form
	@Override
	public DiagnosisPojo fetchDiagnosisUpdate(String reportId) throws ApplicationException {
		DiagnosisPojo diagnosisPojo = new DiagnosisPojo();
		SessionFactory sessionFactory7 = null;
		Session session7 = null;
		DiagnosisEntity diagnosisEntity = new DiagnosisEntity();
		try {
			
			sessionFactory7 = HibernateUtil.getSessionFactory();
			session7 = sessionFactory7.openSession();

		
			diagnosisEntity = (DiagnosisEntity) session7.get(DiagnosisEntity.class, reportId);

			diagnosisPojo.setReportId(reportId);
			diagnosisPojo.setPhysicianId(diagnosisEntity.getPhysicianEntity().getPhysicianId());
			diagnosisPojo = DiagnosisDaoImpl.diagnosisPojoMethod(diagnosisEntity, diagnosisPojo);

		} catch (HibernateException he7) {
			ApplicationException ae7 = new ApplicationException(he7.getMessage());
			throw ae7;
		} finally {
			session7.close();
		}
		return diagnosisPojo;
	}

	static DiagnosisPojo diagnosisPojoMethod(DiagnosisEntity diagnosisEntity, DiagnosisPojo diagnosisPojo) {

		diagnosisPojo.setPatientId(diagnosisEntity.getPatientEntity().getPatientId());

		diagnosisPojo.setServiceDate(diagnosisEntity.getServiceDate());
		diagnosisPojo.setTestResultDate(diagnosisEntity.getTestResultDate());
		diagnosisPojo.setNormalValue1(diagnosisEntity.getNormalValue1());
		diagnosisPojo.setActualValue1(diagnosisEntity.getActualValue1());
		diagnosisPojo.setNormalValue2(diagnosisEntity.getNormalValue2());
		diagnosisPojo.setActualValue2(diagnosisEntity.getActualValue2());
		diagnosisPojo.setNormalValue3(diagnosisEntity.getNormalValue3());
		diagnosisPojo.setActualValue3(diagnosisEntity.getActualValue3());
		diagnosisPojo.setNormalValue4(diagnosisEntity.getNormalValue4());
		diagnosisPojo.setActualValue4(diagnosisEntity.getActualValue4());
		diagnosisPojo.setNormalValue5(diagnosisEntity.getNormalValue5());
		diagnosisPojo.setActualValue5(diagnosisEntity.getActualValue5());
		diagnosisPojo.setNormalValue6(diagnosisEntity.getNormalValue6());
		diagnosisPojo.setActualValue6(diagnosisEntity.getActualValue6());
		diagnosisPojo.setMedicine1(diagnosisEntity.getMedicine1());

		diagnosisPojo.setMedicine3(diagnosisEntity.getMedicine3());
		diagnosisPojo.setMedicine2(diagnosisEntity.getMedicine2());

		diagnosisPojo.setMedicine5(diagnosisEntity.getMedicine5());
		diagnosisPojo.setMedicine4(diagnosisEntity.getMedicine4());
		diagnosisPojo.setMedicine6(diagnosisEntity.getMedicine6());
		diagnosisPojo.setPhysicianComment(diagnosisEntity.getPhysicianComments());
		diagnosisPojo.setOtherInfo(diagnosisEntity.getOtherInfo());
		return diagnosisPojo;

	}

}