package com.hospital.dao;

import java.util.ArrayList;

import com.hospital.exception.ApplicationException;

public interface PatientHistoryDao {
	ArrayList fetchPatientHistory(String patientId) throws ApplicationException;

}
