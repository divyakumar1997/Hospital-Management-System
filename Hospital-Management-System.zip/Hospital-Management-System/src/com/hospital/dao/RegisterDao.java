package com.hospital.dao;

import com.hospital.exception.ApplicationException;
import com.hospital.model.AdminPojo;
import com.hospital.model.PhysicianPojo;

public interface RegisterDao {

	int adminLogin(AdminPojo adminPojo) throws ApplicationException;

	String registerAdmin(AdminPojo adminPojo) throws ApplicationException;

	int physicianLogin(PhysicianPojo physicianPojo) throws ApplicationException;

	String getAdminName(String adminId) throws ApplicationException;

	String getPhysicianName(String physicianId) throws ApplicationException;
}
