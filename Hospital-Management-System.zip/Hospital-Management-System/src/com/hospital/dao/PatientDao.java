package com.hospital.dao;

import java.util.ArrayList;

import com.hospital.exception.ApplicationException;
import com.hospital.model.PatientPojo;

public interface PatientDao {
	String registerPatient(PatientPojo patientPojo) throws ApplicationException;

	void updatePatient(PatientPojo patientPojo) throws ApplicationException;

	ArrayList fetchPatient() throws ApplicationException;

	PatientPojo fetchPatientUpdate(String patientId) throws ApplicationException;
}
