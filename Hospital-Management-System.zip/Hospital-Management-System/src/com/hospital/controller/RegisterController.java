package com.hospital.controller;

import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.hospital.exception.ApplicationException;
import com.hospital.model.AdminPojo;
import com.hospital.model.PhysicianPojo;
import com.hospital.service.PhysicianService;
import com.hospital.service.RegisterService;

@Controller
public class RegisterController {
	static final Logger LOG = Logger.getLogger("HospitalManagement");
	@Autowired
	public RegisterService registerService;
	@Autowired
	public AdminPojo adminPojo;
	@Autowired
	public PhysicianService physicianService;

	@RequestMapping("/adminRegistration")
	public ModelAndView adminRegistration(ModelMap map9) {
		ModelAndView mav9 = null;
		map9.addAttribute("register", new AdminPojo());
		mav9 = new ModelAndView("AdminRegistration");
		return mav9;
	}

	@RequestMapping("/home")
	public ModelAndView viewHome(ModelMap map10) {
		ModelAndView mav10 = null;
		map10.addAttribute("register", adminPojo);

		mav10 = new ModelAndView("Home");
		return mav10;
	}

	@RequestMapping(value = "/registerAdmin", method = RequestMethod.POST)
	public ModelAndView registerAdmin(@Valid @ModelAttribute("register") AdminPojo adminPojo, BindingResult result,
			HttpServletRequest request, HttpSession session, ModelMap map11) {
		ModelAndView mav11 = null;

		if (result.hasErrors()) {
			mav11 = new ModelAndView("AdminRegistration");
			return mav11;
		}
		String adminId = null;
		try {
			adminId = registerService.registerAdmin(adminPojo);
		} catch (ApplicationException ae11) {
			LOG.info(ae11.getMessage());
			mav11 = new ModelAndView("ApplicationError");
			return mav11;
		}

		map11.addAttribute("id", adminId);
		map11.addAttribute("success", "success");
		mav11 = new ModelAndView("Home");
		return mav11;

	}

	@RequestMapping("/")
	public ModelAndView login(ModelMap map12) {
		ModelAndView mav12 = null;

		map12.addAttribute("register", new AdminPojo());

		mav12 = new ModelAndView("Home");
		return mav12;

	}

	@RequestMapping("/logout")
	public ModelAndView logout(HttpSession session, ModelMap map13, HttpServletRequest request) {
		ModelAndView mav13 = null;
		if (session.getAttribute("name") == null) {
			map13.addAttribute("register", new AdminPojo());
			mav13 = new ModelAndView("Home");
			return mav13;
		} else {

			session.invalidate();
			map13.addAttribute("register", new AdminPojo());
			mav13 = new ModelAndView("Home");
			return mav13;

		}
	}

	@RequestMapping("/physicianLogout")
	public ModelAndView physicianLogout(HttpSession session, ModelMap map14, HttpServletRequest request) {
		ModelAndView mav14 = null;
		if (session.getAttribute("name") == null) {
			map14.addAttribute("loginPhysician", new PhysicianPojo());
			mav14 = new ModelAndView("PhysicianLogin");
			return mav14;

		} else {

			session.invalidate();
			map14.addAttribute("loginPhysician", new PhysicianPojo());
			mav14 = new ModelAndView("PhysicianLogin");
			return mav14;
		}
	}

	@RequestMapping(value = "/loginAdmin", method = RequestMethod.POST)
	public ModelAndView loginAdmin(HttpServletRequest request, @ModelAttribute("register") AdminPojo adminPojo,
			ModelMap map15) {
		ModelAndView mav15 = null;

		int login = 0;

		try {
			login = registerService.adminLogin(adminPojo);
		} catch (ApplicationException ae15) {
			LOG.info(ae15.getMessage());
			mav15 = new ModelAndView("ApplicationError");
			return mav15;
		}

		if (login == 1) {
			String adminId = adminPojo.getAdminId();
			String adminName = null;
			try {
				adminName = registerService.getAdminName(adminId);
			} catch (ApplicationException ae_15) {
				LOG.info(ae_15.getMessage());
				mav15 = new ModelAndView("ApplicationError");
				return mav15;

			}
			HttpSession session = request.getSession();
			session.setAttribute("name", adminName);
			mav15 = new ModelAndView("Main");
			return mav15;
		} else if (login == 0) {
			map15.addAttribute("error", "error");
			mav15 = new ModelAndView("Home");
			return mav15;
		} else {
			map15.addAttribute("error1", "error1");
			mav15 = new ModelAndView("Home");
			return mav15;
		}

	}

	@RequestMapping(value = "/homePage", method = RequestMethod.GET)
	public ModelAndView homePage(HttpServletRequest request, @ModelAttribute("register") AdminPojo adminPojo,
			ModelMap map16) {
		ModelAndView mav16 = new ModelAndView("Main");
		return mav16;

	}

	@RequestMapping(value = "/physicianHomePage", method = RequestMethod.GET)
	public ModelAndView homePage(HttpServletRequest request,
			@ModelAttribute("loginPhysician") PhysicianPojo physiciannPojo, ModelMap map) {
		ModelAndView mav17 = new ModelAndView("PhysicianMain");
		return mav17;

	}

	@RequestMapping("/physicianLoginPage")
	public ModelAndView physicianLoginPage(ModelMap map18) {
		ModelAndView mav18 = null;
		map18.addAttribute("loginPhysician", new PhysicianPojo());
		mav18 = new ModelAndView("PhysicianLogin");
		return mav18;
	}

	@RequestMapping(value = "/loginPhysician", method = RequestMethod.POST)
	public ModelAndView loginPhysician(HttpServletRequest request,
			@ModelAttribute("loginPhysician") PhysicianPojo physicianPojo, ModelMap map19) {

		ModelAndView mav19 = null;

		int login = 0;

		try {

			login = registerService.physicianLogin(physicianPojo);

		} catch (ApplicationException ae19) {
			LOG.info(ae19.getMessage());
			mav19 = new ModelAndView("ApplicationError");
			return mav19;
		}

		if (login == 1) {
			String physicianName = null;
			String physicianId = physicianPojo.getPhysicianId();
			try {
				physicianName = registerService.getPhysicianName(physicianId);

			} catch (ApplicationException ae_19) {
				LOG.info(ae_19.getMessage());
				mav19 = new ModelAndView("ApplicationError");
				return mav19;

			}
			HttpSession session = request.getSession();
			session.setAttribute("name", physicianName);

			session.setAttribute("physicianId", physicianId);
			mav19 = new ModelAndView("PhysicianMain");
			return mav19;
		} else if (login == 0) {

			map19.addAttribute("error", "error");
			mav19 = new ModelAndView("PhysicianLogin");
			return mav19;
		} else {

			map19.addAttribute("error1", "error1");
			mav19 = new ModelAndView("PhysicianLogin");
			return mav19;
		}

	}

}
