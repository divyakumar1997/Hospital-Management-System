package com.hospital.controller;

import java.util.ArrayList;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hospital.exception.ApplicationException;
import com.hospital.model.AdminPojo;

import com.hospital.service.PatientHistoryService;

@Controller
public class PatientHistoryController {
	static final Logger LOG = Logger.getLogger("HospitalManagement");
	@Autowired
	PatientHistoryService patientHistoryService;

	@RequestMapping("/patientHistory")
	public ModelAndView patientHistory(@RequestParam("id") String patientId, ModelMap map20, HttpServletRequest request,
			HttpSession session) {
		ModelAndView mav20 = null;
		// session = request.getSession();
		if (session.getAttribute("name") == null) {
			map20.addAttribute("session", "session");
			map20.addAttribute("register", new AdminPojo());
			mav20 = new ModelAndView("Home");
			return mav20;
		} else {

			ArrayList patientHistoryDetails = null;

			try {
				patientHistoryDetails = patientHistoryService.fetchPatientHistory(patientId);
			} catch (ApplicationException ae20) {
				LOG.info(ae20.getMessage());
				mav20 = new ModelAndView("ApplicationError");
				return mav20;
			}
			if (patientHistoryDetails.isEmpty()) {

				mav20 = new ModelAndView("ViewPatientHistory");
				mav20.addObject("record", "No report Found");
				return mav20;
			} else {

				mav20 = new ModelAndView("ViewPatientHistory");
				mav20.addObject("patientHistoryDetails", patientHistoryDetails);
				return mav20;
			}

		}
	}

}
