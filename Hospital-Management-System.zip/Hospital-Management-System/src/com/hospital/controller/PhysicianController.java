package com.hospital.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Logger;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.hospital.exception.ApplicationException;
import com.hospital.model.AdminPojo;

import com.hospital.model.PhysicianPojo;
import com.hospital.service.DiagnosisService;
import com.hospital.service.PhysicianService;

@Controller
public class PhysicianController {
	static final Logger LOG = Logger.getLogger("HospitalManagement");
	@Autowired
	PhysicianService physicianService;

	@Autowired
	DiagnosisService diagnosisService;

	@RequestMapping("/physicianFetch")
	public ModelAndView physicianFetch(HttpServletRequest request, HttpSession session, ModelMap map1)
			throws ApplicationException {

		ModelAndView mav1 = null;
		if (session.getAttribute("name") == null) {
			map1.addAttribute("session", "session");
			map1.addAttribute("register", new AdminPojo());
			mav1 = new ModelAndView("Home");
			return mav1;
		} else {

			List physicianList = null;
			try {
				physicianList = physicianService.fetchPhysician();
			} catch (ApplicationException ae1) {
				LOG.info(ae1.getMessage());
				mav1 = new ModelAndView("ApplicationError");
				return mav1;
			}
			map1.addAttribute("physicianDetails", physicianList);
			mav1 = new ModelAndView("PhysicianDisplay");
			return mav1;
		}
	}

	@RequestMapping(value = "/physicianSearch", method = RequestMethod.GET)
	public ModelAndView physicianSearch(HttpServletRequest request, ModelMap map2,
			@ModelAttribute("physician") PhysicianPojo physicianPojo, HttpSession session) throws ApplicationException {
		ModelAndView mav2 = null;
		if (session.getAttribute("name") == null) {
			map2.addAttribute("session", "session");
			map2.addAttribute("register", new AdminPojo());
			mav2 = new ModelAndView("Home");
			return mav2;
		} else {

			List physicianList = null;

			try {
				physicianList = physicianService.fetchPhysician();
			} catch (ApplicationException ae2) {
				LOG.info(ae2.getMessage());
				mav2 = new ModelAndView("ApplicationError");
				return mav2;
			}
			map2.addAttribute("physicianDetails", physicianList);
			mav2 = new ModelAndView("PhysicianSearch");
			return mav2;
		}
	}

	@RequestMapping(value = "/physicianForm", method = RequestMethod.GET)
	public ModelAndView physicianForm(ModelMap map3, HttpSession session,
			@ModelAttribute("physician") PhysicianPojo physicianPojo) {
		ModelAndView mav3 = null;
		if (session.getAttribute("name") == null) {
			map3.addAttribute("session", "session");
			map3.addAttribute("register", new AdminPojo());
			mav3 = new ModelAndView("Home");
			return mav3;
		} else {

			mav3 = new ModelAndView("AddPhysician");
			return mav3;
		}
	}

	@RequestMapping("/physicianUpdate")
	public ModelAndView physicianUpdate(@RequestParam("id") String physicianId, HttpSession session, ModelMap map4,
			HttpServletRequest request) {
		ModelAndView mav4 = null;
		if (session.getAttribute("name") == null) {
			map4.addAttribute("session", "session");
			map4.addAttribute("register", new AdminPojo());
			mav4 = new ModelAndView("Home");
			return mav4;
		} else {

			PhysicianPojo physicianPojo = null;
			try {
				physicianPojo = physicianService.fetchPhysicianUpdate(physicianId);
			} catch (ApplicationException ae4) {
				LOG.info(ae4.getMessage());
				mav4 = new ModelAndView("ApplicationError");
				return mav4;
			}

			map4.addAttribute("physician", new PhysicianPojo());
			map4.addAttribute("update", physicianPojo);
			mav4 = new ModelAndView("PhysicianUpdate");
			return mav4;
		}

	}

	@RequestMapping(value = "/searchPhysician", method = RequestMethod.POST)
	public ModelAndView searchPhysician(HttpServletRequest request,
			@ModelAttribute("physician") PhysicianPojo physicianPojo, ModelMap map5, HttpSession session) {
		ModelAndView mav5 = null;
		if (session.getAttribute("name") == null) {
			map5.addAttribute("session", "session");
			map5.addAttribute("register", new AdminPojo());
			mav5 = new ModelAndView("Home");
			return mav5;
		} else {

			String hospital = physicianPojo.getHospital();
			String speciality = physicianPojo.getSpeciality();
			List physicianList = null;

			try {
				if (hospital == null && speciality == null) {
					map5.addAttribute("error", "error");
					mav5 = new ModelAndView("PhysicianSearch");
					return mav5;
				} else {

					physicianList = physicianService.searchPhysician(hospital, speciality);
				}
			} catch (ApplicationException ae5) {
				LOG.info(ae5.getMessage());
				mav5 = new ModelAndView("ApplicationError");
				return mav5;
			}

			if (physicianList.isEmpty()) {
				mav5 = new ModelAndView("SearchResult");
				mav5.addObject("record", "No Doctor Found");
				return mav5;

			} else {

				map5.addAttribute("physicianList", physicianList);
				mav5 = new ModelAndView("SearchResult");
				return mav5;
			}

		}
	}

	@RequestMapping(value = "/updatePhysician", method = RequestMethod.POST)
	public ModelAndView updatePhysician(HttpServletRequest request,
			@Valid @ModelAttribute("physician") PhysicianPojo physicianPojo, BindingResult result, ModelMap map6,
			HttpSession session) throws ApplicationException {
		ModelAndView mav6 = null;
		if (session.getAttribute("name") == null) {
			map6.addAttribute("session", "session");
			map6.addAttribute("register", new AdminPojo());
			mav6 = new ModelAndView("Home");
			return mav6;
		} else {

			String physicianId = physicianPojo.getPhysicianId();

			if (result.hasErrors()) {
				PhysicianPojo physicianPojo1 = new PhysicianPojo();
				physicianPojo1 = physicianService.fetchPhysicianUpdate(physicianId);
				map6.addAttribute("update", physicianPojo1);
				mav6 = new ModelAndView("PhysicianUpdate");
				return mav6;
			}
			List physicianDetails = null;
			try {
				physicianService.updatePhysician(physicianPojo);
				physicianDetails = physicianService.fetchPhysician();
			} catch (ApplicationException ae6) {
				LOG.info(ae6.getMessage());
				mav6 = new ModelAndView("ApplicationError");
				return mav6;
			}
			map6.addAttribute("physicianDetails", physicianDetails);
			map6.addAttribute("physicianId", physicianPojo.getPhysicianId());
			map6.addAttribute("update", "update");
			mav6 = new ModelAndView("PhysicianDisplay");
			return mav6;
		}
	}

	@RequestMapping(value = "/addPhysician", method = RequestMethod.POST)
	public ModelAndView addPhysician(HttpServletRequest request, ModelMap map7,
			@Valid @ModelAttribute("physician") PhysicianPojo physicianPojo, BindingResult result,
			HttpSession session) {
		ModelAndView mav7 = null;
		if (session.getAttribute("name") == null) {
			map7.addAttribute("session", "session");
			map7.addAttribute("register", new AdminPojo());
			mav7 = new ModelAndView("Home");
			return mav7;

		} else {

			if (result.hasErrors()) {
				mav7 = new ModelAndView("AddPhysician");
				return mav7;
			}
			String physicianId = null;
			ArrayList physicianDetails = null;
			try {
				physicianId = physicianService.addPhysician(physicianPojo);
				physicianDetails = (ArrayList) physicianService.fetchPhysician();
			} catch (ApplicationException ae7) {
				LOG.info(ae7.getMessage());
				mav7 = new ModelAndView("ApplicationError");
				return mav7;
			}

			map7.addAttribute("id", physicianId);
			map7.addAttribute("success", "success");

			map7.addAttribute("physicianDetails", physicianDetails);
			mav7 = new ModelAndView("PhysicianDisplay");
			return mav7;
		}
	}

	@RequestMapping("/physicianFetchPatient")
	public ModelAndView physicianFetchPatient(@RequestParam("id") String physicianId, HttpServletRequest request,
			HttpSession session, ModelMap map8) throws ApplicationException {

		ModelAndView mav8 = null;
		if (session.getAttribute("name") == null) {
			map8.addAttribute("session", "session");
			map8.addAttribute("loginPhysician", new PhysicianPojo());
			mav8 = new ModelAndView("PhysicianLogin");
			return mav8;

		} else {

			ArrayList patientDetailsForPhysician = null;
			try {

				patientDetailsForPhysician = diagnosisService.fetchDiagnosisDetailsPhysician(physicianId);

			} catch (ApplicationException ae8) {
				LOG.info(ae8.getMessage());
				mav8 = new ModelAndView("ApplicationError");
				return mav8;

			}
			mav8 = new ModelAndView("PhysicianFetchPatient");
			if (patientDetailsForPhysician.size() == 0) {

				mav8.addObject("No Patient Found", "No Patient Found");

			}

			else {

				mav8.addObject("patientDetailsForPhysician", patientDetailsForPhysician);

			}
			return mav8;
		}
	}

}
