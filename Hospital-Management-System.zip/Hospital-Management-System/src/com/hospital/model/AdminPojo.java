package com.hospital.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.springframework.stereotype.Component;

@Component("adminPojo")
public class AdminPojo {
	private String adminId;

	@Pattern(regexp = "^[ A-Za-z]+$", message = "Name should not contain numbers")
	@Size(max = 50, message = "First Name should not exceed 50 characters")
	private String firstName;

	@Pattern(regexp = "^[ A-Za-z]+$", message = "Name should not contain numbers")
	@Size(max = 50, message = "Last Name should  not exceed 50 characters")
	private String lastName;

	@Min(value = 1, message = "Age should be positive number")

	private int age;

	private String gender;

	private String dateOfBirth;

	@Min(value = 1, message = "Contact number should contain only positive number")
	private long contactNumber;

	@Min(value = 0, message = "Contact number should contain only positive number")
	private long alternateContactNumber;

	@Email
	private String emailId;

	private String password;

	private String confirmPassword;

	public String getAdminId() {
		return adminId;
	}

	public String getGender() {
		return gender;
	}

	public long getContactNumber() {
		return contactNumber;
	}

	public long getAlternateContactNumber() {
		return alternateContactNumber;
	}

	public String getEmailId() {
		return emailId;
	}

	public String getPassword() {
		return password;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public int getAge() {
		return age;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setAdminId(String adminId) {
		this.adminId = adminId;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setContactNumber(long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public void setAlternateContactNumber(long alternateContactNumber) {
		this.alternateContactNumber = alternateContactNumber;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setPassword(String password) {
		this.password = password;
	}

}
