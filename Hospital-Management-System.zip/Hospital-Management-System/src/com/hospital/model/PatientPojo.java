package com.hospital.model;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.springframework.stereotype.Component;

@Component("patientPojo")
public class PatientPojo {

	private String patientId;
	@Size(max = 50, message = "First Name should not exceed 50 characters")
	@Pattern(regexp = "^[ A-Za-z]+$", message = "Name should not contain numbers")
	private String firstName;

	private String gender;
	private String dateOfBirth;

	@Min(value = 1, message = "Contact number should contain only positive number")
	private Long phone;

	@Min(value = 0, message = "Contact number should contain only positive number")
	private Long alternatePhone;

	@Email
	private String emailId;
	@Pattern(regexp = "^[ A-Za-z]+$", message = "Name should not contain number")
	@Size(max = 50, message = "Last Name should  not exceed 50 characters")
	private String lastName;

	@Size(max = 100, message = "Address Line should  not exceed 100 characters")
	private String addressLine1;
	@Size(max = 50, message = "state Name should  not exceed 50 characters")
	private String state;

	@Size(max = 50, message = "City should  not exceed 50 characters")
	private String city;
	@Size(max = 100, message = "Address Line should  not exceed 100 characters")
	private String addressLine2;
	@Min(value = 1, message = "Age should not  less than 1")
	@Max(value = 100, message = "Enter Valid age")
	private Integer age;
	private Integer zipCode;

	private String password;

	public PatientPojo() {
		super();
		// TODO Auto-generated constructor stub
	}

	public PatientPojo(String patientId, String firstName, String lastName, Integer age, String gender,
			String dateOfBirth, String emailId, String password, String addressLine1, String addressLine2, String state,
			String city, Integer zipCode, Long phone, Long alternatePhone) {
		super();
		this.patientId = patientId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.phone = phone;
		this.alternatePhone = alternatePhone;
		this.emailId = emailId;
		this.addressLine1 = addressLine1;
		this.addressLine2 = addressLine2;
		this.state = state;
		this.city = city;
		this.zipCode = zipCode;
		this.password = password;
	}

	public void setPatientId(String patientId) {
		this.patientId = patientId;
	}

	public String getFirstName() {
		return firstName;
	}

	public Integer getAge() {
		return age;
	}

	public String getLastName() {
		return lastName;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getGender() {
		return gender;
	}

	public Long getPhone() {
		return phone;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public void setPhone(Long phone) {
		this.phone = phone;
	}

	public String getEmailId() {
		return emailId;
	}

	public Long getAlternatePhone() {
		return alternatePhone;
	}

	public void setAlternatePhone(Long alternatePhone) {
		this.alternatePhone = alternatePhone;
	}

	public String getPatientId() {
		return patientId;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getState() {
		return state;
	}

	public String getCity() {
		return city;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setZipCode(Integer zipCode) {
		this.zipCode = zipCode;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getZipCode() {
		return zipCode;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getPassword() {
		return password;
	}

}
