package com.hospital.model;

public class DiagnosisValuePojo {
	// Class that has Diagnosis values
	private String diagnosis;
	private String value;

	public String getDiagnosis() {
		return diagnosis;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getValue() {
		return value;
	}

	public void setDiagnosis(String diagnosis) {
		this.diagnosis = diagnosis;
	}

}
