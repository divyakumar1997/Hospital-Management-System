package com.hospital.model;

import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

@Component("physicianPojo")
public class PhysicianPojo {

	private String physicianId;

	@Pattern(regexp = "^[ A-Za-z]+$", message = "Name should not contain number")
	@Size(max = 50, message = "First Name should not exceed 50 characters")
	private String firstName;

	@Min(value = 1, message = "Age should not be less than 1")
	private Integer age;
	@Size(max = 50, message = "Last Name should  not exceed 50 characters")
	@Pattern(regexp = "^[ A-Za-z]+$", message = "Name should not contain numbers")
	private String lastName;

	private String gender;
	private String dateOfBirth;

	@Min(value = 1, message = "Contact number should contain only positive number")
	private Long contactNumber;
	@Min(value = 0, message = "Contact number should contain only positive number")
	private Long alternateContactNumber;
	private String emailId;

	@Size(max = 100, message = "Address Line should  not exceed 100 characters")
	private String addressLine1;

	@Size(max = 100, message = "Address Line should  not exceed 100 characters")
	private String addressLine2;

	@Size(max = 50, message = "City should  not exceed 50 characters")
	private String city;
	@Size(max = 50, message = "state Name should  not exceed 50 characters")
	private String state;
	@Min(value = 1, message = "Zipcode must be positive number")
	private String zipCode;
	private String password;

	@Size(max = 50, message = "Degree Name should  not exceed 50 characters")
	private String degree;

	@Size(max = 50, message = "Speciality should  not exceed 50 characters")
	private String speciality;
	private String workHours;

	@Size(max = 100, message = "Hospital Name should  not exceed 100 characters")
	private String hospital;

	public PhysicianPojo() {
		super();
	}

	public PhysicianPojo(String physicianId, String firstName, String lastName, Integer age, String gender,
			String dateOfBirth, Long contactNumber, Long alternateContactNumber, String emailId, String password,
			String addressLine1, String addressLine2, String city, String state, String zipCode, String degree,
			String speciality, String workHours, String hospital) {

		this.physicianId = physicianId;

		this.age = age;
		this.lastName = lastName;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
		this.contactNumber = contactNumber;
		this.alternateContactNumber = alternateContactNumber;
		this.emailId = emailId;
		this.firstName = firstName;

		this.addressLine2 = addressLine2;

		this.addressLine1 = addressLine1;
		this.city = city;
		this.zipCode = zipCode;
		this.state = state;
		this.password = password;
		this.degree = degree;
		this.speciality = speciality;
		this.workHours = workHours;
		this.hospital = hospital;
	}

	public String getPhysicianId() {
		return physicianId;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public Long getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(Long contactNumber) {
		this.contactNumber = contactNumber;
	}

	public Long getAlternateContactNumber() {
		return alternateContactNumber;
	}

	public void setState(String state) {
		this.state = state;
	}

	public void setAlternateContactNumber(Long alternateContactNumber) {
		this.alternateContactNumber = alternateContactNumber;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public String getCity() {
		return city;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setDegree(String degree) {
		this.degree = degree;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getDegree() {
		return degree;
	}

	public void setPhysicianId(String physicianId) {
		this.physicianId = physicianId;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public String getWorkHours() {
		return workHours;
	}

	public void setWorkHours(String workHours) {
		this.workHours = workHours;
	}

	public String getHospital() {
		return hospital;
	}

	public void setHospital(String hospital) {
		this.hospital = hospital;
	}

}
